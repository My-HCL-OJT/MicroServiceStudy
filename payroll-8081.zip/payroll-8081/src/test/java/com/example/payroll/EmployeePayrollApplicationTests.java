package com.example.payroll;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePayrollApplicationTests {

	@Test
	void contextLoads() {
	}

}
