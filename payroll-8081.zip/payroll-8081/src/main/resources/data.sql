insert into EMPLOYEE_SALARY (ID, SALARY) values (1, 10000);
insert into EMPLOYEE_SALARY (ID, SALARY) values (2, 20000);